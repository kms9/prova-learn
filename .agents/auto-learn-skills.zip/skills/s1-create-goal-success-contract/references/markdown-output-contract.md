# S1 完整 Markdown 文档契约

本文件规定 S1 的第一份必交工件：供人逐段校对的完整 Markdown 文档。它不是 JSON 摘要、执行日志或
HTML 使用说明。建议文件名为 `<run_id>-S1-review.md`。

## 1. 三工件中的位置

1. 先完成 Markdown 中的阶段事实、分析、结论、证据和缺口。
2. 再把同一内容无损结构化为 `handoff-envelope.schema.json` 与
   `goal-success-contract.schema.json` 对应的 JSON。
3. 校验 Markdown 与 JSON 的语义对应后，再从最终 JSON 派生交互 HTML。
4. JSON/HTML 生成后，只允许回填路径、工件标识、校验状态等机械信息；如新增或修改实质结论，必须同步
   更新 Markdown 与 JSON 并重新校验。

Markdown 是首要的人审文档；JSON 是机器移交的规范表示；HTML 是 JSON 驱动的只读展示。三者内容不得
互相矛盾，JSON 不得把 Markdown 简化成少数字段或只保留结论。

## 2. 必须使用的文档结构

以下一级章节必须按顺序出现；可以在章节内增加二级、三级标题。

1. `# S1 目标与成功契约审核报告`
2. `## 1. 文档与运行信息`
3. `## 2. 输入与需求审计`
4. `## 3. 外部预检与证据边界`
5. `## 4. 目标理解与术语校准`
6. `## 5. 完整能力要求`
7. `## 6. 最终验收设计与通过规则`
8. `## 7. 范围、约束、排除项与风险`
9. `## 8. S2 领域研究简报`
10. `## 9. 确认结果、开放问题与阻断项`
11. `## 10. G1 质量评价与路由`
12. `## 11. 输出审计与 JSON 对应表`

## 3. 各章节必须回答的问题

| 章节 | 必须完整呈现的内容 | 主要 JSON Pointer |
|---|---|---|
| 文档与运行信息 | 阶段、运行标识、状态、时间、学习者/受众、数据性质 | `/stage_id`、`/run_id`、`/status`、`/created_at`、`/learner_id`、`/traceability` |
| 输入与需求审计 | 原始诉求、实际输入、缺失信息、假设、输入校验；区分用户事实与推断 | `/input_contract`、`/input_validation`、`/requirement_gaps`、`/assumptions` |
| 外部预检与证据边界 | 实际检索动作、六类预检覆盖、来源、证据等级、未执行项；不得把模型记忆写成外部证据 | `/evidence_collected`、`/processing_record`、`/positive_artifact/content/external_research_seed` |
| 目标理解与术语校准 | 目标问题、目标场景、对象、岗位族/层级和术语校正；不复述已否决的无关旧目标 | `/positive_artifact/content/target_problem`、`/positive_artifact/content/target_scene`、`/positive_artifact/content/terminology_corrections` |
| 完整能力要求 | 能力阶梯、每项能力的任务、行为、产物、质量标准、自主性与边界；不得只给能力名称 | `/positive_artifact/content/observable_capabilities` |
| 最终验收设计与通过规则 | 未见任务、认知层级、证据、评分/判定规则、迁移要求、失败条件 | `/positive_artifact/content/final_assessment`、`/positive_artifact/content/pass_rules` |
| 范围与风险 | 纳入范围、排除项、时间/资源/环境/语言约束、风险和禁止事项 | `/positive_artifact/content/scope`、`/positive_artifact/content/constraints`、`/positive_artifact/content/exclusions`、`/requirement_gaps` |
| S2 研究简报 | 领域边界、角色层级、地区语言、时间窗、问题、来源限制及六源检索种子 | `/positive_artifact/content/domain_research_brief` |
| 确认与阻断 | 确认问题、回答、变更、仍开放问题、恢复条件 | `/confirmation`、`/requirement_gaps` |
| G1 与路由 | 每个量规维度的证据、得分、阈值、通过情况、裁决和下一阶段 | `/quality_evaluation` |

## 4. 完整性要求

- “完整能力要求”必须逐项解释能力为什么可观察、如何验收及达到何种质量，不得只列三五个标签。
- 引用结论时保留来源标识、证据状态、适用范围和不确定性。
- `pending`、`blocked` 或 `return_upstream` 也必须生成完整诊断文档，明确已知、未知、未执行与恢复条件；
  不得用空标题、`TBD`、`TODO`、`待补充`或示例占位符冒充内容。
- 已被用户否决且与当前目标无关的案例不得在正文或 HTML 中继续传播。

## 5. 输出审计与对应表

末章必须列出 Markdown、JSON、HTML 三个路径及状态，并包含逐章节对应表：

| `section_id` | Markdown 标题 | JSON Pointer（可多项） | 对应检查 |
|---|---|---|---|

每个一级章节至少映射一个真实 JSON Pointer。对应检查必须说明 `matched`、`gap` 或 `not_applicable`；
存在 `gap` 时 `document_artifact.validation.json_correspondence` 不得为 `pass`。
