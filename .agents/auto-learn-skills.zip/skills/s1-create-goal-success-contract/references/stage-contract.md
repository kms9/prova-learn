# S1 阶段契约 — create-goal-success-contract（门 G1）

> 本文件治理 S1 与决策门 G1。§0 为七阶段共享规则；其余为 S1 专属。

## 0. 共享阶段契约（适用于 S1–S7）

- **编号定义**：`Sx` 是第 x 个执行阶段（Stage），`Gx` 是紧随 Sx、评价该阶段工件能否被下游消费的质量决策门（Gate）。例如 `G1` 是 S1 目标契约质量门，不是学习理论、外部标准或另一个 Skill。
- **“已通过 Gx”的机读含义**：不能凭文件存在、自然语言声称或只看 `positive_artifact` 推断。对作为上游输入的 G1–G6，消费方必须验证兼容移交信封同时满足：`stage_id=Sx`、`status=completed`、`input_validation.status=pass`、具名 `positive_artifact` 非空且通过其 Schema、该门要求的全部 `quality_evaluation.rubric_results[].passed=true`、`quality_evaluation.verdict=pass`、`quality_evaluation.route_to=S{x+1}`，并满足该阶段确认规则；三工件交付还要求 `document_artifact.status=generated` 与 `presentation_artifact.status=generated`。上游 Skill 未与当前 Skill 一起安装时，也必须由调用方提供这些字段或先适配成兼容信封；裸工件只能记为未验证输入。

每个阶段必须产出**三份内容一致、用途不同的工件**：

1. 一份按当前阶段专属结构撰写的完整 Markdown 人审文档；
2. 一份把 Markdown 全部实质内容无损结构化的规范 JSON 移交信封（`handoff-envelope.schema.json`）；
3. 一份由最终 JSON 填充的阶段专用交互 HTML。

统一执行形状：

```text
校验输入契约
→ 收集需求缺口
→ 执行本阶段确认策略
→ 收集可采信证据
→ 先完成阶段专属 Markdown 的事实、分析、结论、量规与路由
→ 将同一内容无损结构化为具名正向工件与 JSON 移交信封
→ 校验 Markdown 章节与 JSON Pointer 的逐项对应
→ 派生并验证阶段专用 HTML
```

- **三工件权威边界**：Markdown 是首要人审文档，JSON 是机器移交的规范表示，HTML 是 JSON 驱动的
  只读派生视图。Markdown 与 JSON 必须语义等价，不能以“摘要 JSON”丢弃文档中的证据、边界、缺口、
  失败条件、异议或路由依据。
- **严格生成顺序**：先完成 Markdown 实质内容，再生成 JSON，最后生成 HTML。JSON/HTML 生成后只允许
  回填路径、工件标识和验证状态等机械信息；实质内容变化必须同步 Markdown 与 JSON 并重新验证。
- **输入契约校验**：至少检查工件类型、schema 版本、必填字段、来源阶段、追溯与上游门状态。失败时 `input_validation.status=fail` 并路由上游，**不得伪造正向工件**。
- **确认状态机**：`mandatory`（S1/S5，未确认不得前进）、`conditional`（S2/S3/S4/S7，遇高风险/分歧/多方案升级为强制）、`inform`（S6 节点推进，告知后继续）。
- **证据来源分类**：`model_hypothesis`/`market_signal`/`external_evidence`/`user_provided_unverified`/`learner_behavior`。**门不得把 `model_hypothesis` 或 `user_provided_unverified` 计为外部证据。**
- **量规结果形状**：`{dimension, evidence[], score, threshold, passed, failure_action, route_to}`；`passed=false` 时 `failure_action` 与 `route_to` 必填。
- **显式未知/阻塞态**：`pending`/`blocked`/`unknown`/`evidence_insufficient`/`research_blocked`/`not_executed`/`version_conflict` 不得被强制为 `pass`。
- **确定性路由**：`pass` 前进；`revise_here` 同阶段重试；`return_upstream` 指向**最早**污染阶段并记录失效下游范围。S7 多归因按上游优先级路由。
- **合并守卫**：快速档仅可在满足条件时合并 S2+S3 或 S4+S5，仍须分别产出工件并依次通过两门；S1、S7 永不合并。
- **强制完整文档**：每次运行都必须遵守当前 skill 的 `markdown-output-contract.md`。`pending` 或
  `blocked` 也要完整写明已知事实、未知项、未执行项、当前结论与恢复条件；禁止空标题、空表、`TBD`、
  `TODO`、示例数据或其他占位内容。
- **强制页面派生**：每次运行都必须基于最终信封生成已填充的本阶段专用 HTML；`pending` 或 `blocked` 也展示真实缺口、当前结论和恢复条件，不得使用通用装载器或空白占位。
- **只生成数据驱动页面**：HTML 是唯一可视化交付，页面视图必须由内嵌规范 JSON 动态渲染；禁止调用制图/图像生成工具，禁止生成、引用或依赖独立图片、插图、知识点图卡或其他静态图片资产。
- **只读展示边界**：页面交互仅用于切换、搜索、筛选、展开和浏览既有数据；不得接受业务输入、导出草稿，或展示 Schema、模板、Markdown/HTML 生成状态及输出说明。
- **交付完整性**：Markdown、JSON 或 HTML 任一缺失，Markdown—JSON 对应失败，或 HTML 三项验证任一
  失败时，均不得把本次阶段交付报告为完整完成；文档/页面失败不篡改领域门禁本身。

## 1. S1 目的

把模糊的“我想学 X”与一次有边界的强制联网预检，校准为经过外部校准、用户确认、可观察、可验收的目标契约。S1 是“目标校准—领域研究”对（S1–S2）的目标校准半边。

## 2. S1 输入契约

| 输入 | 是否必填 | 说明 |
|---|---|---|
| 学习者诉求/目标问题 | 必填 | 冷启动可模糊 |
| 目标使用场景 | 必填 | 至少一个场景或问题 |
| 既有材料 | 可选 | 须保留来源标识；未验证材料不得默认为事实 |

冷启动允许不完整；未确认推断与模型知识不得写成已确认目标。

## 3. S1 确认策略（强制）

用户确认：目标能力、成功证据、范围、岗位族/目标职级、地区/行业/语言、时效窗口、时间/资源/形式约束、风险级别、排除项。`confirmation.status=pending` 时门不得通过。用户中途根本改变目标时，无论流程进行到哪，都返回 S1。

## 4. S1 强制联网预检（不可降级）

- 确认前执行，即便模型“知道”该领域。
- 至少查询：Wikipedia/百科（术语+相邻概念）、当前 JD（任务/工具/职级）、面试/实操样本，以及 S2 可追溯的岗位、书课、论文、社区、标准、真实产物六类来源入口。
- 记录 `external_research_seed`：`search_executed`、`retrieval_date`、`queries`、`sources`（仅 `market_signal`/`external_evidence`）、`category_coverage`。预检覆盖类别固定为
  `wikipedia_encyclopedia / official_academic / practice_case / recruiting_jd / interview_selection / adversarial_frontier`；
  六类各出现一次，并记录 `covered`/`not_applicable`/`gap` + `reason` + `gate_effect`。
- `not_applicable` 必须给出可审计理由；找不到资料记为 `gap`，不是 `not_applicable`。
- 形成 `domain_research_brief`：领域边界、岗位族/目标职级、地区/语言、时间窗口、风险级别、重点问题、六源检索种子与来源限制。该简报只约束 S2，不代表已完成六源研究或领域全景。
- S1 预检类别与 S2 证据通道不是同一分类，必须按实际来源归属映射：
  `wikipedia_encyclopedia` 仅作发现入口；`official_academic` 按来源进入 `books_courses`、`papers_research` 或
  `standards_official`；`recruiting_jd` 进入 `job_career`；`practice_case` 与 `interview_selection` 通常进入
  `artifacts_validation`，若只是社区转述则只能进入 `community_web`；`adversarial_frontier` 按出处进入
  `papers_research`、`community_web` 或 `artifacts_validation`。S2 必须重新核验实际来源，不得按类别名自动升级证据等级。
- 无联网/检索能力时：`status=blocked`，G1 失败，不得用模型记忆替代预检。

## 5. S1 工件字段（`goal_success_contract.content`）

`target_problem`、`target_scene`、`terminology_corrections[]`（`original/corrected/evidence_refs`）、`observable_capabilities[]`（`capability_id/statement/observable_evidence[]`，每项≥1 可观察证据）、`final_assessment`（`tasks[]` + `unseen_or_transfer_required`）、`pass_rules[]`、`scope[]`、`exclusions[]`、`constraints{}`、`domain_research_brief`（`role_family/target_level/region/languages/time_window/decision_risk/priority_questions/source_constraints/six_source_seeds`）、`external_research_seed`、`open_questions[]`、`confirmed_items[]`（≥1）。

## 6. S1 量规（门 G1）

| 维度 | 阈值类型 | 阈值 | 证据来源 |
|---|---|---|---|
| 目标可观察性 | 每项能力≥1 可观察证据 | ≥1 | observable_capabilities.observable_evidence |
| 成功标准可判定性 | unseen_or_transfer_required | true | final_assessment |
| 场景真实性 | target_scene 非空 | true | target_scene |
| 外部现实校准度 | 有 terminology_corrections 或确认无歧义 | true | terminology_corrections |
| 强制类别覆盖 | 六类固定预检类别均有唯一状态，wiki/recruiting/interview covered 或可审计 | true | external_research_seed.category_coverage |
| S2 研究范围可执行 | 目标岗位/场景、地区语言、时效和六源种子明确 | true | domain_research_brief |
| 边界清晰 | exclusions 非空 | ≥1 | exclusions |
| 约束完整 | 时间/形式约束存在 | true | constraints |
| 目标—验收一致 | pass_rules 与能力、验收对齐 | true | pass_rules |

G1 通过当且仅当**所有维度** `passed=true` 且 `confirmation.status=confirmed` 且无关键证据缺口阻塞目标确认。

## 7. S1 路由

| verdict | route_to | 触发 |
|---|---|---|
| `pass` | S2 | 全部 G1 维度通过 + 已确认 |
| `revise_here` | S1 | 目标/成功标准不清、术语漂移、预检未执行或仅模型总结 |
| `return_upstream` | S1 | 用户根本改变目标（S1 是最早阶段，上游返回即重回 S1） |
| `blocked` | S1 | 无联网能力或关键缺口未解决 |

## 8. S1 安全/阻塞态

- 冷启动缺输入 → 记录 `requirement_gaps`，保持 `pending`，不伪造。
- 无检索能力 → `blocked`；G1 失败；不得通过。
- 关键来源类别缺口 → 门阻塞，除非缩小范围、降低置信度并记录缺口。
- 强制确认未完成 → `pending`；G1 不得通过。
