---
name: al-01-create-goal-success-contract
description: 将模糊学习诉求、职业目标或能力愿望校准为经过外部预检、可观察、可验收并由用户确认的 goal_success_contract，并按“完整 Markdown 人审文档→无损结构化 JSON→JSON 驱动的 S1 交互 HTML”交付三份工件，全程不生成独立图片。只要用户要开始新的个性化学习目标、改变既有目标、定义“学会”的证据，或需要校正岗位/领域名称，就使用本 skill。
---

# 目标与成功契约（S1）

把目标定义错误隔离在流程最前端。不要直接生成课程表，也不要把投入时长、看完材料或选择题分数当成能力。

## 独立运行时的阶段、门与依赖

- `S1` 表示本 Skill 执行的“目标与成功契约”阶段；`G1` 表示紧随 S1 的目标契约质量门。`G1` 不是学习理论，也不是另一个 Skill。
- 本 Skill 没有上游阶段依赖，可由学习者诉求、目标场景和可选既有材料独立启动。
- `G1` 通过是指：外部预检真实执行，目标能力与成功证据可观察，未见/迁移验收可判定，范围、排除项和约束明确，S2 研究简报可执行，用户强制确认完成，G1 全部量规维度通过；移交信封必须为 `stage_id=S1`、`quality_evaluation.verdict=pass`、`quality_evaluation.route_to=S2`。
- 仅生成 `goal_success_contract` 文件、仅由模型声称“目标清楚”，或确认仍为 `pending`，都不算通过 G1。

## 开始前

1. 读取 [stage-contract.md](references/stage-contract.md)。
2. 读取 [markdown-output-contract.md](references/markdown-output-contract.md)，按 S1 专属章节先生成完整人审文档。
3. 读取 [handoff-envelope.schema.json](references/handoff-envelope.schema.json) 和 [goal-success-contract.schema.json](references/goal-success-contract.schema.json)。
4. 读取 [html-visualization-contract.md](references/html-visualization-contract.md)；必须使用 [stage-report.html](assets/stage-report.html) 生成已填充的 S1 专用页面。
5. 仅在需要理解输出形状时读取 [example.md](references/example.md)；案例数据是设计夹具，不是真实观察。

## 执行

1. 校验是否至少有一个目标问题或使用场景；记录缺失约束，不把推断写成已确认事实。
2. 收集目标场景、受众、岗位族/目标职级、地区/行业/语言、时效窗口、时间、资源、输出形式、排除项、风险级别和最终验收方式。
3. 执行轻量外部预检：
   - 术语、别名和相邻概念；
   - 相关真实任务、岗位或实践；
   - 面试、实操、认证或其他可观察评估方式；
   - S2 可继续追溯的岗位、书课、论文、社区、标准与真实产物六类来源入口。
   `external_research_seed.category_coverage` 固定记录百科入口、官方/学术、实践案例、招聘 JD、
   面试/选拔、对抗/前沿六类 S1 预检类别；它们不是 S2 六源通道，必须按实际出处映射，不能按名称自动升级证据等级。
4. 把模型知识只标为 `model_hypothesis`。把招聘样本标为 `market_signal`；只有实际检索到的可访问来源才能标为 `external_evidence`。
5. 形成 S2 研究简报：锁定领域边界、比较岗位族/职级、地区语言、时间窗口、重点问题、来源限制和需要实时复核的动态信息；只生成检索种子，不在 S1 宣称完成领域全景。
6. 展示术语校正、目标选项、成功证据、范围和关键假设，执行强制确认。
7. 将目标反推成可观察能力阶梯和未见验收任务；区分记忆、解释、应用、诊断、迁移和创造。
8. 生成 `goal_success_contract`，再按 G1 量规逐项评价。

用户已经否决、替换或声明无关的旧目标、旧场景和案例内容不得进入当前正向工件，也不得为了说明
“不做什么”而在页面中复述。`terminology_corrections` 只保留理解当前目标所必需的真实术语校正；
不得把被否决的具体业务场景包装成反例继续展示。若审计确有必要，只在处理记录中使用
“先前目标已被替换”之类的中性摘要，不复述无关目标的具体内容。

## Fail closed

- 无联网/检索能力时，输出 `research_blocked`，保持 G1 失败；不要用模型记忆替代预检。
- 强制确认未完成时，保持 `pending`；不要进入 S2。
- 关键来源缺失时记录 `gap`、重要性和门禁影响；“找不到”不等于 `not_applicable`。
- S1 的少量岗位或资料样本只能用于校准目标与生成查询，不得被包装成六源覆盖、领域共识或完整能力模型。
- 用户根本改变目标时重新执行 S1，不在下游静默改写目标。
- 用户否决的旧目标不得作为术语校正、排除项、确认问题或其他展示内容继续传播到当前 JSON 与 HTML。

## 输出

每次运行必须依次交付三份工件：

1. 按 S1 文档契约写成的完整 Markdown 审核报告，详细呈现输入、外部预检、目标理解、完整能力要求、
   验收设计、范围、研究简报、确认、G1 与路由；
2. 符合共同 Schema `1.3.0` 和正向工件 Schema 的 JSON 移交信封。JSON 是 Markdown 的无损结构化表示，
   不是简化摘要；`document_artifact` 必须记录文档路径、S1 profile、逐章节 JSON Pointer 对应与四项验证；
3. 由最终 JSON 填充的 S1 目标、能力、测评、范围与确认专用交互 HTML。

待确认或阻断时仍生成三份含真实缺口、处理记录和路由的诊断工件。不得显示通用文件装载器或空白占位。
页面交互只用于切换、筛选和展开既有阶段数据，不接受确认输入，也不展示 Schema、模板或 Markdown/HTML 生成状态。
HTML 是本阶段唯一可视化交付；所有视图必须由内嵌规范 JSON 在页面内动态渲染。禁止调用
`imagegen`、`image_gen` 或其他制图工具，禁止生成、引用或依赖独立的插图、知识点图片、静态图卡及
PNG/JPEG/WebP/SVG/GIF 等图片资产。用户提到“图片”或“可视化”时，默认实现为页面内的数据视图，
不得自动解释为制图任务。
Markdown 生成或对应验证失败写入 `document_artifact`；HTML 生成或验证失败写入
`presentation_artifact`。二者不得篡改 G1 门禁，但任一失败时整次阶段交付不得报告为完成。只有外部预检已执行、核心能力均有
可观察证据、验收任务与目标对齐且确认完成时，才允许 `verdict=pass`、`route_to=S2`。
