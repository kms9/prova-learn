# S2 阶段契约 — create-domain-evidence-landscape（门 G2）

> 本文件治理 S2 与决策门 G2。§0 为七阶段共享规则；其余为 S2 专属。

## 0. 共享阶段契约（适用于 S1–S7）

- **编号定义**：`Sx` 是第 x 个执行阶段（Stage），`Gx` 是紧随 Sx、评价该阶段工件能否被下游消费的质量决策门（Gate）。例如 `G1` 是 S1 目标契约质量门，不是学习理论、外部标准或另一个 Skill。
- **“已通过 Gx”的机读含义**：不能凭文件存在、自然语言声称或只看 `positive_artifact` 推断。对作为上游输入的 G1–G6，消费方必须验证兼容移交信封同时满足：`stage_id=Sx`、`status=completed`、`input_validation.status=pass`、具名 `positive_artifact` 非空且通过其 Schema、该门要求的全部 `quality_evaluation.rubric_results[].passed=true`、`quality_evaluation.verdict=pass`、`quality_evaluation.route_to=S{x+1}`，并满足该阶段确认规则；三工件交付还要求 `document_artifact.status=generated` 与 `presentation_artifact.status=generated`。上游 Skill 未与当前 Skill 一起安装时，也必须由调用方提供这些字段或先适配成兼容信封；裸工件只能记为未验证输入。

每个阶段必须产出**三份内容一致、用途不同的工件**：

1. 一份按当前阶段专属结构撰写的完整 Markdown 人审文档；
2. 一份把 Markdown 全部实质内容无损结构化的规范 JSON 移交信封（`handoff-envelope.schema.json`）；
3. 一份由最终 JSON 填充的阶段专用交互 HTML。

统一执行形状：

```text
校验输入契约
→ 收集需求缺口
→ 执行本阶段确认策略
→ 收集可采信证据
→ 先完成阶段专属 Markdown 的事实、分析、结论、量规与路由
→ 将同一内容无损结构化为具名正向工件与 JSON 移交信封
→ 校验 Markdown 章节与 JSON Pointer 的逐项对应
→ 派生并验证阶段专用 HTML
```

- **三工件权威边界**：Markdown 是首要人审文档，JSON 是机器移交的规范表示，HTML 是 JSON 驱动的只读派生视图。Markdown 与 JSON 必须语义等价，不能以“摘要 JSON”丢弃文档中的证据、边界、缺口、失败条件、异议或路由依据。
- **严格生成顺序**：先完成 Markdown 实质内容，再生成 JSON，最后生成 HTML。JSON/HTML 生成后只允许回填路径、工件标识和验证状态等机械信息；实质内容变化必须同步 Markdown 与 JSON 并重新验证。
- **输入契约校验**：至少检查工件类型、schema 版本、必填字段、来源阶段、追溯与上游门状态。失败时 `input_validation.status=fail` 并路由上游，**不得伪造正向工件**。
- **确认状态机**：`mandatory`（S1/S5，未确认不得前进）、`conditional`（S2/S3/S4/S7，遇高风险/分歧/多方案升级为强制）、`inform`（S6 节点推进，告知后继续）。
- **证据来源分类**：`model_hypothesis`/`market_signal`/`external_evidence`/`user_provided_unverified`/`learner_behavior`。**门不得把 `model_hypothesis` 或 `user_provided_unverified` 计为外部证据。**
- **量规结果形状**：`{dimension, evidence[], score, threshold, passed, failure_action, route_to}`；`passed=false` 时 `failure_action` 与 `route_to` 必填。
- **显式未知/阻塞态**：`pending`/`blocked`/`unknown`/`evidence_insufficient`/`research_blocked`/`not_executed`/`version_conflict` 不得被强制为 `pass`。
- **确定性路由**：`pass` 前进；`revise_here` 同阶段重试；`return_upstream` 指向**最早**污染阶段并记录失效下游范围。S7 多归因按上游优先级路由。
- **合并守卫**：快速档仅可在满足条件时合并 S2+S3 或 S4+S5，仍须分别产出工件并依次通过两门；S1、S7 永不合并。
- **强制完整文档**：每次运行都必须遵守当前 skill 的 `markdown-output-contract.md`。`pending` 或 `blocked` 也要完整写明已知事实、未知项、未执行项、当前结论与恢复条件；禁止空标题、空表、`TBD`、`TODO`、示例数据或其他占位内容。
- **强制页面派生**：每次运行都必须基于最终信封生成已填充的本阶段专用 HTML；`pending` 或 `blocked` 也展示真实缺口、当前结论和恢复条件，不得使用通用装载器或空白占位。
- **只生成数据驱动页面**：HTML 是唯一可视化交付，页面视图必须由内嵌规范 JSON 动态渲染；禁止调用制图/图像生成工具，禁止生成、引用或依赖独立图片、插图、知识点图卡或其他静态图片资产。
- **只读展示边界**：页面交互仅用于切换、搜索、筛选、展开和浏览既有数据；不得接受业务输入、导出草稿，或展示 Schema、模板、Markdown/HTML 生成状态及输出说明。
- **交付完整性**：Markdown、JSON 或 HTML 任一缺失，Markdown—JSON 对应失败，或 HTML 三项验证任一失败时，均不得把本次阶段交付报告为完整完成；文档/页面失败不篡改领域门禁本身。

## 1. S2 目的

建立可追溯的领域事实基础，识别共识、分歧、核心思维模型、边界与未决问题。S2 是“目标校准—领域研究”对（S1–S2）的领域研究半边，负责回答“依据是什么”，不负责画能力图，也不把搜索结果数量当成证据质量。完整执行规则见 `six-source-information-collection.md`。

## 2. S2 输入契约

| 输入 | 是否必填 | 说明 |
|---|---|---|
| `goal_success_contract` | 必填 | 必须已通过 G1；含目标、可观察成功证据、范围、排除项、岗位/地区/语言/时效、`domain_research_brief` 与 `external_research_seed` |
| 用户提供的资料 | 可选 | 须保留来源标识；未验证材料不得默认视为领域事实，只能作为线索 |

冷启动允许输入不完整；但未确认推断与模型知识不得写成已确认的领域事实。若上游 `goal_success_contract` 未通过 G1、类型/版本不符或追溯缺失，记 `input_validation.status=fail` 并路由上游，**不得伪造正向工件**。

## 3. S2 确认策略（conditional，可升级为 mandatory）

默认 `conditional`：对争议范围、来源限制、地区/岗位口径、研究深度与成本做条件确认；先展示研究视角、核心问题、必查来源类别与预期深度。

升级为 `mandatory` 的触发：高风险或前沿主题、存在活跃分歧或多个竞争范式、目标本身因取证结果需要变更、或资料质量明显不均。`confirmation.status=pending` 时门不得通过。

## 4. S2 强制联网 + STORM 多视角研究（不可降级）

- 取 STORM 研究内核：从相邻主题发现多种视角，由不同视角提出问题，检索互联网资料，让回答严格落在检索来源上并继续追问，最后策展为可追溯的结构化全景。模型自身知识只能用于提出待验证假设、视角、问题与检索词，**不能充当外部证据**。
- 默认至少覆盖六类研究视角：术语与历史、理论与标准、实践者与真实任务、招聘者与市场能力、面试官/评估者与可观察证据、批评者与前沿争议；可增加学习者、管理者、安全/伦理、地区文化等视角。研究视角不等于证据通道。
- 强制多轮：冲突或新发现必须触发后续查询，**不允许只做一次搜索**；记录 `rounds` 与 `follow_up_triggers`。
- 强制证据通道固定为：`job_career / books_courses / papers_research / community_web / standards_official / artifacts_validation`。每类记 `covered / not_applicable / gap` + `reason` + `criticality` + `independent_source_count` + `gate_effect`。`not_applicable` 必须给出可审计理由；找不到资料记为 `gap`。
- 招聘样本去重并记录组织/地区/职级/日期，至少 3 个当前岗位样本、2 个不同组织；比较岗位族、行业、地区、时间与组织类型，把任务、知识、技能、工具、自主性、复杂度、影响、责任与经验情境分别编码。
- 书课比较教材、Handbook、大学课程与认证；论文覆盖综述/分类、奠基、高引、近三年前沿与批评/失败；社区只产生问题、误解、变通、争议、失败和新兴信号；标准提供规范语言；真实产物提供成功/失败条件与可验证结果。
- 所有来源统一抽取为 `Task / Capability / Knowledge / Skill / Evidence`，按需保留 `Tool / Practice / Failure / Misconception / ResearchQuestion / Role / Source`。跨来源同义项归并但保留原词、边界和来源。
- 为核心一级/二级候选建立多源覆盖矩阵。默认至少有岗位/任务、书课或标准、论文/产物/经验证实践三类独立支持；单一来源热度不得决定核心性。
- 连续两轮没有新增一级能力域或关键二级问题族，才标记结构饱和；查询重复或结果变少不算饱和。
- 无联网/检索能力时：`status=blocked`，`research_run_manifest.online=false`、`execution_status=blocked`，G2 失败；用户确认**不能**豁免外部证据门。

## 5. S2 工件字段（`domain_evidence_landscape.content`）

`scope`、`terminology[]`、`research_executed`、`research_run_manifest`、`source_ledger[]`、`category_coverage[]`（六类证据通道）、`normalized_evidence_items[]`（统一原子对象）、`multi_source_coverage_matrix[]`、`structural_saturation`、`landscape_maturity`、`refresh_policy[]`、`role_capability_ladder[]`、`core_questions_and_mental_models`、`jd_capability_matrix[]`、`interview_assessment_matrix[]`、`consensus[]`、`disagreements[]`、`open_problems[]`、`claims[]`（`status=supported/partially_supported/unsupported` + `knowledge_status=consensus/disputed/emerging/insufficient_evidence/deprecated` + `evidence_refs`）、`evidence_gaps[]`。

`source_ledger[].published_at` 保留来源实际公开的精度：允许完整日期 `YYYY-MM-DD`、年月 `YYYY-MM`、年份 `YYYY` 或未知 `null`；不得为满足 Schema 而伪造缺失的月或日。`retrieved_at` 始终使用完整 `date-time`，用于时效复核。

枚举：`provenance` ∈ {model_hypothesis, market_signal, external_evidence, user_provided_unverified, learner_behavior}；`source_category` ∈ {job_career, books_courses, papers_research, community_web, standards_official, artifacts_validation}；`reliability` ∈ {high, medium, low, unknown}。

## 6. S2 量规（门 G2）

| 维度 | 阈值类型 | 阈值 | 证据来源 |
|---|---|---|---|
| 实际联网执行 | research_executed 且 online 且 execution_status=completed | true | research_run_manifest |
| 六源证据通道覆盖 | 六类均有状态、独立样本数且默认样本量达标或可审计 | true | category_coverage |
| 来源可靠性与时效 | 关键结论可追溯至可靠、当前来源 | true | source_ledger |
| 结论可追溯性 | 每项 claim 有 evidence_refs | true | claims.evidence_refs |
| STORM 视角与问题多样性 | perspectives≥6 且各有 questions 与 query_ids | ≥6 | research_run_manifest.perspectives |
| 后续追问深度 | rounds≥1 且冲突触发后续查询 | true | research_run_manifest.rounds/follow_up_triggers |
| 岗位/面试样本代表性 | 招聘≥3 样本/2 组织；面试≥2 组；未达标记 gap | true | jd_capability_matrix / interview_assessment_matrix |
| 时效与地区适配性 | retrieved_at、region 与目标口径一致 | true | source_ledger |
| 事实/市场信号/推断分离 | market_signal 未被写成 fact；模型假设未计为外部证据 | true | claims.claim_type + evidence_collected.provenance |
| 争议平衡 | 重要争议未被单边伪装成共识，保留双方强论据 | true | disagreements.side_a/side_b |
| 证据缺口透明度 | 缺口显式标记且含 confidence_impact | true | evidence_gaps |
| 原子对象可复用 | Task/Capability/Knowledge/Skill/Evidence 有稳定 ID、来源、状态和边界 | true | normalized_evidence_items |
| 多源覆盖 | 核心一级/二级候选默认有三类独立证据通道 | true | multi_source_coverage_matrix |
| 结构饱和 | 连续两轮无新增一级能力域或关键二级问题族 | true | structural_saturation |
| 成熟度诚实 | 达到 L1 才声明领域全景就绪，L2–L4 缺口透明 | true | landscape_maturity |
| 时效治理 | 稳定/动态知识和复核条件已区分 | true | refresh_policy |

G2 通过当且仅当**所有维度** `passed=true`、`research_executed=true`、`landscape_maturity.level=L1_landscape` 或更高、结构饱和已达到，且无关键证据缺口阻塞建图。

## 7. S2 路由

| verdict | route_to | 触发 |
|---|---|---|
| `pass` | S3 | 全部 G2 维度通过、研究已实际执行、缺口不阻塞建图 |
| `revise_here` | S2 | 研究过浅/不平衡/过期、来源类别缺失、查询仅一次、冲突未解释、样本不足 |
| `return_upstream` | S2 | S3 建图发现来源空白，或 S7 `evidence_feedback` 报告来源错误、过期、覆盖不足/冲突时，回到 S2 对受影响 claim/node 局部补证，不推倒无关结果 |
| `return_upstream` | S1 | 目标本身实质改变（成功契约失效），回最早污染阶段 |
| `blocked` | S2 | 无联网能力或 `research_run_manifest.online=false` |

## 8. S2 安全/阻塞态

- 上游未通过 G1 → `input_validation.status=fail`，路由 S1，不伪造 landscape。
- 无联网/检索能力 → `status=blocked`，`research_blocked`，G2 失败，不得用模型记忆替代取证。
- 关键来源类别缺口 → 记 `gap`、`criticality`、`gate_effect`、`confidence_impact`；阻塞相应决策门；“找不到”不等于 `not_applicable`。
- 招聘条件不是科学事实，面试题不是能力本体，百科只作为全景入口；社区热度、论文热度、岗位词频、单本教材目录也不可单独支撑核心或高风险结论。
- 六类来源不能直接拼成六个大纲章节；S2 只交付证据和原子对象，S3 才组织能力结构。
- 重大范围变化（取证中发现目标需调整）→ 回到条件确认或返回 S1，不在下游静默改写目标。

## 9. 快速档与研究档附加门

- **S2+S3 允许合并**：领域成熟、单一范式、低风险、来源质量实质均匀；合并执行仍须先输出 `domain_evidence_landscape` 并通过 G2，再输出图谱并评价 G3。
- **S2+S3 禁止合并**：竞争范式、活跃分歧、来源可靠性明显不均、证据快速变化、前沿/高风险决策任一成立时，必须分开执行。
- **研究档专家门**：若研究档声明需要独立外部专家复核，但没有实际专家证据，记录 `pending` 或 `not_executed`；允许保存初步工件，但不得声称“研究档完成”或把专家门推断为已通过。
