# S2 完整 Markdown 文档契约

本文件规定 S2 的第一份必交工件：供人审阅研究过程、来源和结论的完整 Markdown 文档。它不是来源清单
摘要，也不是把 JSON 字段换成标题。建议文件名为 `<run_id>-S2-review.md`。

## 1. 三工件顺序与权威边界

先写完整 Markdown，随后把同一研究事实和判断无损结构化为规范 JSON，完成逐章节对应校验后，再由最终
JSON 派生 S2 交互 HTML。Markdown 是首要人审文档，JSON 是机器移交规范表示，HTML 是只读派生视图。
生成 JSON/HTML 后只可机械回填路径和验证状态；实质内容变化必须同步三者并重验。

## 2. 必须使用的文档结构

1. `# S2 领域证据全景审核报告`
2. `## 1. 文档与运行信息`
3. `## 2. 上游输入与研究范围审计`
4. `## 3. 研究问题、视角、轮次与检索方法`
5. `## 4. 六源覆盖与来源台账`
6. `## 5. 归一化证据原子`
7. `## 6. 主张—证据与知识状态`
8. `## 7. 真实任务、角色阶梯与能力深度`
9. `## 8. 核心问题、心智模型与实践信号`
10. `## 9. 共识、分歧、误概念与开放问题`
11. `## 10. 饱和度、成熟度、时效与刷新策略`
12. `## 11. 证据缺口、限制与下游影响`
13. `## 12. G2 质量评价与路由`
14. `## 13. 输出审计与 JSON 对应表`

## 3. 阶段内容与 JSON 对应

| 内容块 | 必须完整呈现 | 主要 JSON Pointer |
|---|---|---|
| 输入审计 | G1 工件标识/版本/门状态、目标范围、缺失/过期输入 | `/input_contract`、`/input_validation`、`/requirement_gaps` |
| 研究执行 | 实际视角、研究问题、查询、执行时间、轮次、追问触发和未执行项 | `/positive_artifact/content/research_run_manifest`、`/processing_record` |
| 六源台账 | 六个来源通道各自状态、独立来源数、关键性、门禁影响；每个来源的出版/访问/适用信息 | `/positive_artifact/content/category_coverage`、`/positive_artifact/content/source_ledger` |
| 原子对象 | Task/Capability/Knowledge/Skill/Evidence 等稳定对象、定义与来源 | `/positive_artifact/content/normalized_evidence_items` |
| 主张与知识状态 | 每个关键主张的支持状态、证据引用、反证、边界、稳定/动态/前沿等级 | `/positive_artifact/content/claims` |
| 角色与任务 | 角色/职级、责任范围、真实任务、产物、评价标准和失败方式 | `/positive_artifact/content/role_capability_ladder`、`/positive_artifact/content/jd_capability_matrix`、`/positive_artifact/content/interview_assessment_matrix` |
| 领域认识 | 核心问题、心智模型、实践/工具/失败/误概念线索 | `/positive_artifact/content/core_questions_and_mental_models` |
| 争议与缺口 | 共识、双方最强论据、未决问题、不可泛化项、关键来源缺口 | `/positive_artifact/content/consensus`、`/positive_artifact/content/disagreements`、`/positive_artifact/content/open_problems`、`/positive_artifact/content/evidence_gaps` |
| 研究质量 | 覆盖矩阵、结构饱和、成熟度、时效与刷新规则 | `/positive_artifact/content/multi_source_coverage_matrix`、`/positive_artifact/content/structural_saturation`、`/positive_artifact/content/landscape_maturity`、`/positive_artifact/content/refresh_policy` |
| G2 与路由 | 分维量规、证据、裁决、下游失效范围和下一动作 | `/quality_evaluation`、`/traceability` |

## 4. 完整性要求

- 不能只给“发现了什么”；必须让审核者看见如何研究、引用了什么、为何采信、哪些结论仍不稳定。
- 来源数量不得代替独立性、可靠性与适用性判断；转载链必须显式合并或降权。
- 社区、招聘和市场信号不得改写成领域事实；模型假设不得冒充已检索证据。
- 阻断/局部刷新同样生成完整报告，明确保留项、刷新项、未执行项、失效下游和恢复动作。
- 禁止 `TBD`、`TODO`、`待补充`、空表或示例来源占位符。

## 5. 输出审计

末章列出三工件路径、状态及逐章节 `section_id → Markdown 标题 → JSON Pointer[] → matched/gap/not_applicable`
对应表。每个一级章节至少一个有效 Pointer；任一实质主张只存在于 Markdown 或 JSON 一侧时，一致性失败。
