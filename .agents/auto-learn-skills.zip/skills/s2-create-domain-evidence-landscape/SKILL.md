---
name: al-02-create-domain-evidence-landscape
description: 对已通过 G1（S1 目标与成功契约质量门）的学习目标执行真实联网、STORM 式多视角、多轮六源取证，把岗位、书课、论文、社区、标准和真实产物归一为可追溯的 domain_evidence_landscape，并按“完整 Markdown 人审文档→无损结构化 JSON→JSON 驱动的 S2 交互 HTML”交付三份工件，全程不生成独立图片。只要用户需要进入个性化学习 S2、研究某领域全景、从多源资料提炼任务/能力/知识/技能/证据，或补充 S3 建图暴露的来源空白，就使用本 skill。
---

# 领域取证与认知全景（S2）

负责“依据是什么”，不负责画能力图，也不把搜索结果数量或模型记忆当成证据质量。

## 独立运行时的阶段、门与依赖

- `S2` 是本 Skill 的领域取证阶段；`G2` 是 S2 证据全景质量门。`G1` 是它的直接上游——S1 目标与成功契约质量门；G1/G2 都不是学习理论或独立 Skill 名。
- 直接依赖只有一个：`goal_success_contract`。所谓“已通过 G1”，必须能验证 S1 移交信封的 `stage_id=S1`、`status=completed`、`input_validation.status=pass`、非空且 Schema 合法的 `goal_success_contract`、G1 全量规通过、`quality_evaluation.verdict=pass`、`route_to=S2` 和强制确认完成。
- `G1` 的业务含义是目标、可观察成功证据、范围/排除项、约束、外部预检和 S2 研究简报均已确认；只有裸 `goal_success_contract` 或一句“G1 已通过”只能作为未验证输入。
- `G2` 通过是指真实联网多轮六源研究已执行，覆盖、追溯、冲突、结构饱和、至少 L1 成熟度、时效和关键缺口均满足 G2 量规，最终 `verdict=pass`、`route_to=S3`。
- 本 Skill 不要求 S1 Skill 目录与它共同安装；若调用方提供符合上述字段的兼容移交信封即可独立运行，否则记录 prerequisite gap 并返回 S1。

## 开始前

1. 读取 [stage-contract.md](references/stage-contract.md)。
2. 读取 [markdown-output-contract.md](references/markdown-output-contract.md)，按 S2 专属章节先生成完整人审文档。
3. 读取 [handoff-envelope.schema.json](references/handoff-envelope.schema.json) 和 [domain-evidence-landscape.schema.json](references/domain-evidence-landscape.schema.json)。
4. 读取 [six-source-information-collection.md](references/six-source-information-collection.md)，按其中的来源角色、抽取对象、覆盖/饱和门和时效规则执行。
5. 读取 [html-visualization-contract.md](references/html-visualization-contract.md)；必须使用 [stage-report.html](assets/stage-report.html) 生成已填充的 S2 专用页面。
6. 仅为理解输出形状时读取 [example.md](references/example.md)；案例数据是设计夹具，不是真实观察。
7. 校验上游 `goal_success_contract` 已通过 G1，范围、可观察成功证据、确认、研究简报和 `external_research_seed` 可用。

## 执行

1. 基于 S1 目标框定主题、地区、语言、岗位/应用场景、时间边界与研究深度。
2. 同时建立研究视角与六类证据通道。研究视角用于提问；强制证据通道固定为：岗位与职业、书籍与课程、论文与研究图谱、社区与网络讨论、标准与官方框架、真实产物与验证证据。两者不得混为同一分类。
3. 为每个视角提出核心问题、反例问题与后续追问；执行多轮联网查询，冲突或新发现必须触发后续检索，**不允许只做一次搜索**。
4. 建立来源台账与六源覆盖表；为每类来源记 `covered / not_applicable / gap`、理由、关键性、独立样本数与门禁影响。`not_applicable` 必须写明理由；找不到资料记为 `gap`。
5. 分开标记 `external_evidence`、`market_signal`、`model_hypothesis`、`user_provided_unverified`；模型知识只能作假设与查询生成器，不能当外部来源。
6. 适用时招聘研究至少覆盖 3 个当前岗位样本、2 个组织，并控制岗位族、地区、行业、时间和组织类型；书课比较权威教材、Handbook、大学课程与认证体系；论文覆盖综述/分类、奠基、高引、近三年前沿与负面结果；社区只作为问题/失败/争议信号；未达标记 `undersample gap`，不补造样本。
7. 把所有来源统一抽取为 `Task / Capability / Knowledge / Skill / Evidence`，并按需保留 `Tool / Practice / Failure / Misconception / ResearchQuestion / Role / Source`；每个原子项保留来源、证据状态、知识状态、时效和适用边界。
8. 建立 claim→evidence 映射与多源覆盖矩阵，区分 `supported / partially_supported / unsupported` 以及 `consensus / disputed / emerging / insufficient_evidence / deprecated`；把市场信号、社区信号与规范事实并列而非合并。
9. 执行结构饱和检查：连续两轮没有新增一级能力域或关键二级问题族，才能声明 `domain_landscape_ready`；仍允许记录三级项和案例增量。评定 L0–L4 成熟度，本阶段正常目标为 L1，并明确通往 L2 的缺口。
10. 为稳定知识与动态知识分别设置复核策略；招聘、工具、前沿和社区信号不得沿用过期来源。
11. 若输入来自 S7 `evidence_feedback`，按 `affected_claim_refs`、`affected_node_ids`、`suggested_queries`
    和 `invalidated_downstream` 限定补证范围；修复来源错误、过期、覆盖不足或未处理冲突，并保留未受影响结果。
12. 生成 `domain_evidence_landscape`，再按 G2 量规逐项评价。

## Fail closed

- 无真实查询清单、只有模型常识或少量未审计页面时，G2 失败。
- 无联网/检索能力时输出 `research_blocked`，`status=blocked`；用户确认不能豁免外部证据门。
- 资料不存在时记为 `gap`；只有确实不适用并写明理由时才能用 `not_applicable`。
- 招聘条件不是科学事实，面试题不是能力本体，百科只作为全景入口。
- 社区热度、论文热度、职位词频或单本教材目录都不得直接决定核心大纲；六类资料不能按来源目录直接拼成课程目录。
- 未达到六源覆盖与结构饱和门时，不得声称 `domain_landscape_ready`；只能保留当前成熟度和缺口。
- S3 建图发现来源空白，或 S7 返回 `evidence_feedback` 时回到 S2 局部补证，不重做无关部分；目标本身改变时返回 S1。

## 输出

每次运行必须依次交付：完整 S2 Markdown 研究审核报告、符合共同 Schema `1.3.0` 与正向工件 Schema
的无损结构化 JSON、由最终 JSON 填充的 S2 交互 HTML。Markdown 必须完整呈现研究范围、问题/视角/轮次、
六源台账、证据原子、主张、角色深度、共识/分歧、成熟度、时效、缺口、G2 与路由；JSON 不得删节为摘要，
并须通过 `document_artifact.section_mappings` 逐章对应。阻断时仍生成三份工件，展示真实未满足来源门和
返回动作。不得显示通用文件装载器或空白占位。页面交互只用于筛选、比较和展开既有来源与主张，
不接受业务输入，也不展示 Schema、模板或 Markdown/HTML 生成状态。HTML 是本阶段唯一可视化交付；所有视图
必须由内嵌规范 JSON 在页面内动态渲染。禁止调用 `imagegen`、`image_gen` 或其他制图工具，禁止生成、
引用或依赖独立的插图、知识点图片、静态图卡及 PNG/JPEG/WebP/SVG/GIF 等图片资产。用户提到“图片”
或“可视化”时，默认实现为页面内的数据视图，不得自动解释为制图任务。Markdown 失败写入
`document_artifact`，HTML 失败写入 `presentation_artifact`；不得篡改 G2 门禁，但任一失败时整次阶段交付不得报告为完成。只有联网多视角研究已
实际执行并记录、强制来源类别覆盖完整、关键结论可追溯、争议未被
单边伪装成共识、市场信号与事实分开、证据缺口透明且 G2 通过时，才允许 `verdict=pass`、`route_to=S3`。
